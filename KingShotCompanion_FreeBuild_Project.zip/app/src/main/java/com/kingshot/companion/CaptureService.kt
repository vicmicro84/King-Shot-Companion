package com.kingshot.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_SNAP = "com.kingshot.companion.SNAP"
        private const val CHANNEL = "screen_reader"
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var pending = false
    private lateinit var worker: Handler
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private val snapReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { pending = true }
    }

    override fun onCreate() {
        super.onCreate()
        val thread = HandlerThread("screen-ocr").apply { start() }
        worker = Handler(thread.looper)
        val filter = IntentFilter(ACTION_SNAP)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(snapReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(snapReceiver, filter)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(10, notification())
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val resultData = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        if (projection == null && resultData != null && resultCode != 0) startProjection(resultCode, resultData)
        return START_STICKY
    }

    private fun startProjection(resultCode: Int, resultData: Intent) {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, resultData)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                virtualDisplay?.release()
                virtualDisplay = null
                stopSelf()
            }
        }, worker)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader?.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (!pending) { image.close(); return@setOnImageAvailableListener }
            pending = false
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * w
            val full = Bitmap.createBitmap(w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(buffer)
            image.close()
            val cropped = Bitmap.createBitmap(full, 0, 0, w, h)
            full.recycle()
            runOcr(cropped)
        }, worker)
        virtualDisplay = projection?.createVirtualDisplay(
            "KingShotCapture", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, worker
        )
    }

    private fun runOcr(bitmap: Bitmap) {
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val raw = result.text
                val fields = extractFields(raw)
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                getSharedPreferences("game_data", Context.MODE_PRIVATE).edit()
                    .putString("latest_text", raw)
                    .putString("parsed_fields", fields)
                    .putString("last_read", stamp)
                    .putString("history_$stamp", raw)
                    .apply()
                sendBroadcast(Intent("com.kingshot.companion.DATA_UPDATED").setPackage(packageName))
            }
            .addOnFailureListener {
                getSharedPreferences("game_data", Context.MODE_PRIVATE).edit()
                    .putString("latest_text", "OCR failed: ${it.localizedMessage}")
                    .apply()
            }
            .addOnCompleteListener { bitmap.recycle() }
    }

    private fun extractFields(text: String): String {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val labels = listOf("Power", "Level", "Troops", "Kills", "Hero", "VIP", "Might", "Food", "Wood", "Stone", "Iron")
        val found = mutableListOf<String>()
        for (line in lines) {
            if (labels.any { line.contains(it, ignoreCase = true) } &&
                Regex("[0-9][0-9,.]*\s*[KMB]?").containsMatchIn(line)) {
                found.add("• $line")
            }
        }
        return if (found.isEmpty())
            "No confidently labelled fields detected. Review the OCR text below and enter values manually."
        else found.distinct().joinToString("\n") + "\n\nPlease verify each value before using it."
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Game screen reader", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }
    private fun notification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("King Shot Companion")
            .setContentText("Screen reading is active. Tap floating SNAP to read the screen.")
            .setSmallIcon(android.R.drawable.ic_menu_camera).build()
    }

    override fun onDestroy() {
        try { unregisterReceiver(snapReceiver) } catch (_: Exception) {}
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        recognizer.close()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
