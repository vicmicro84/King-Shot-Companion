package com.kingshot.companion

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var data: TextView
    private val requestCapture = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refresh()
    }

    private fun render() {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(0xFFF7F8FC.toInt())
        }
        val title = TextView(this).apply {
            text = "KING SHOT COMPANION 2.0"
            textSize = 22f
            setTextColor(0xFF172033.toInt())
        }
        status = TextView(this).apply {
            textSize = 14f
            setPadding(0, 12, 0, 12)
            setTextColor(0xFF374151.toInt())
        }
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        wrap.addView(title)
        wrap.addView(status)
        wrap.addView(button("1. Allow floating button") { allowOverlay() })
        wrap.addView(button("2. Start screen reading") { requestScreenCapture() })
        wrap.addView(button("Stop floating button") {
            stopService(Intent(this, OverlayService::class.java))
            refresh()
        })
        wrap.addView(button("Refresh saved readings") { refresh() })
        wrap.addView(button("Clear saved OCR history") {
            getSharedPreferences("game_data", Context.MODE_PRIVATE).edit().clear().apply()
            refresh()
        })
        val heading = TextView(this).apply {
            text = "LATEST SCREEN READINGS"
            textSize = 17f
            setPadding(0, 20, 0, 8)
            setTextColor(0xFF172033.toInt())
        }
        data = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF172033.toInt())
            setTextIsSelectable(true)
        }
        wrap.addView(heading)
        wrap.addView(data)
        val scroll = ScrollView(this).apply { addView(wrap) }
        setContentView(scroll)
        refresh()
    }

    private fun allowOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(i)
        } else {
            startService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Floating SNAP enabled", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Android MediaProjection permission callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        if (requestCode == requestCapture && resultCode == RESULT_OK && resultData != null) {
            val intent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, resultData)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            if (Settings.canDrawOverlays(this)) startService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Screen reading permission granted. Return to the game and tap SNAP.", Toast.LENGTH_LONG).show()
        }
    }

    private fun refresh() {
        if (!::data.isInitialized) return
        val p = getSharedPreferences("game_data", Context.MODE_PRIVATE)
        val raw = p.getString("latest_text", "No screenshots have been read yet.") ?: ""
        val parsed = p.getString("parsed_fields", "") ?: ""
        val time = p.getString("last_read", "") ?: ""
        data.text = "Last read: $time\n\n$parsed\n\nOCR text:\n$raw"
        status.text = "Floating overlay: ${Settings.canDrawOverlays(this).let { if (it) "permission allowed" else "permission needed" }}\nReadings are saved on this device."
    }
}
