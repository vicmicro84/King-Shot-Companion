plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.kingshot.companion"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.kingshot.companion"
        minSdk = 26
        targetSdk = 35
        versionCode = 20
        versionName = "2.0.0"
    }
}
dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
