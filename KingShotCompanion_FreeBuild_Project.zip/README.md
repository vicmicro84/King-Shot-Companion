# King Shot Companion 2.0 — free Android build

This is a fresh native Android starter project. It is not a rebuilt copy of v1.5 because an APK alone is not the original editable Android Studio source project.

## What is included
- Floating SNAP overlay button (Android overlay permission required).
- Android MediaProjection screen capture after the user approves the system prompt.
- On-device Google ML Kit text recognition.
- Local persistence of latest OCR text, timestamp, and basic label-associated lines.
- GitHub Actions workflow to compile a debug APK without a paid app-builder subscription.

## Important accuracy and integration limits
- OCR reads pixels/text visible on the captured screen. It does not access King Shot's private game database or GBox internals.
- It cannot guarantee 100% recognition. The extracted lines are suggestions and must be checked before syncing into authoritative hero/stat fields.
- This starter stores OCR output and basic label matches; it does not yet implement a complete King Shot-specific hero database, robust field mapping, auto-detection of GBox foreground state, or automated game-account login.
- Android displays a screen-capture consent prompt. The user must approve it. Android may stop capture when the app/system ends the projection.
- Some Android versions and device manufacturers restrict overlays or screen capture. Test on the actual device and GBox version.
- Never enter your game password into an unofficial companion app.

## Build a free APK with GitHub Actions
1. Create a new GitHub repository (or use a separate branch/repository so the existing private VALR repository is untouched).
2. Upload all files in this folder, preserving the `.github/workflows/build-apk.yml` path.
3. Open the repository's **Actions** tab.
4. Select **Build King Shot Companion APK** and tap **Run workflow** (or push to `main`).
5. When the run completes, open it and download the `KingShotCompanion-debug-apk` artifact.
6. Extract the ZIP artifact on Android and install `app-debug.apk`. You may need to allow installation from that file manager.

GitHub Actions provides a limited free allowance depending on account/repository plan and usage. This project uses no paid app-builder service.

## First launch
1. Open King Shot Companion.
2. Tap **Allow floating button** and grant display-over-other-apps permission.
3. Tap **Start screen reading** and approve Android's screen-capture prompt.
4. Return to GBox/King Shot and tap the floating **SNAP** bubble on a game screen.
5. Reopen the companion to inspect the latest OCR text and candidate labelled fields.

## Technical
- Android Gradle Plugin 8.5.2
- Gradle 8.7
- JDK 17
- Kotlin 2.0.10
- minSdk 26 (Android 8.0)
- targetSdk 35
